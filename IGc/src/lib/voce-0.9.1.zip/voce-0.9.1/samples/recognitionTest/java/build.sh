${JDK_HOME}/bin/javac -classpath ../../../lib/voce.jar recognitionTest.java
