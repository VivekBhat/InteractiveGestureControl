${JDK_HOME}/bin/java -classpath .:../../../lib/voce.jar -mx256m recognitionTest
