${JDK_HOME}/bin/java -classpath .:../../../lib/voce.jar synthesisTest
